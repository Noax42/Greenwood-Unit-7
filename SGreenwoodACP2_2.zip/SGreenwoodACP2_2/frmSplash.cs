﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace SGreenwoodACP2_2
{
    public partial class frmSplash : Form
    {
        public frmSplash()
        {
            InitializeComponent();
        }

        private void frmSplash_Load(object sender, EventArgs e)
        {
            //Have the worker report loading progress and start
            bkgWorker.WorkerReportsProgress = true;
            bkgWorker.RunWorkerAsync();
        }

        private void bkgWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            //Sleep for 50 ms, then start loading.
            for (int i = 1; i <= 100; i++)
            {
                Thread.Sleep(50);
                bkgWorker.ReportProgress(i);
            }
        }

        private void bkgWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //Update the progress bar value and the progress label
            pgrSplash.Value = e.ProgressPercentage;
            lblProgress.Text = e.ProgressPercentage.ToString() + "%";

            //Check if loading is done
            if (pgrSplash.Value >= 100)
            {
                //Hide this form and load main as dialog
                this.Hide();
                new frmMain().ShowDialog();

                //When main closes, this will run and exit the application.
                Application.Exit();
            }
        }
    }
}
