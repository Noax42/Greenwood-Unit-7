﻿
namespace SGreenwoodACP2_2
{
    partial class frmDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvwDisplay = new System.Windows.Forms.ListView();
            this.id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.price = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.quantity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.yearProduced = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.description = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.discontinued = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvwDisplay
            // 
            this.lvwDisplay.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.name,
            this.price,
            this.quantity,
            this.yearProduced,
            this.description,
            this.discontinued});
            this.lvwDisplay.GridLines = true;
            this.lvwDisplay.HideSelection = false;
            this.lvwDisplay.Location = new System.Drawing.Point(12, 12);
            this.lvwDisplay.Name = "lvwDisplay";
            this.lvwDisplay.Size = new System.Drawing.Size(1123, 322);
            this.lvwDisplay.TabIndex = 0;
            this.lvwDisplay.UseCompatibleStateImageBehavior = false;
            this.lvwDisplay.View = System.Windows.Forms.View.Details;
            // 
            // id
            // 
            this.id.Text = "ID";
            this.id.Width = 40;
            // 
            // name
            // 
            this.name.Text = "Name";
            this.name.Width = 100;
            // 
            // price
            // 
            this.price.Text = "Price";
            // 
            // quantity
            // 
            this.quantity.Text = "Quantity";
            // 
            // yearProduced
            // 
            this.yearProduced.Text = "Year Produced";
            this.yearProduced.Width = 100;
            // 
            // description
            // 
            this.description.Text = "Description";
            this.description.Width = 270;
            // 
            // discontinued
            // 
            this.discontinued.Text = "Discontinued?";
            this.discontinued.Width = 90;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(498, 366);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(151, 40);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1144, 417);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lvwDisplay);
            this.Name = "frmDisplay";
            this.Text = "Beverage Data";
            this.Load += new System.EventHandler(this.frmDisplay_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvwDisplay;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader price;
        private System.Windows.Forms.ColumnHeader quantity;
        private System.Windows.Forms.ColumnHeader yearProduced;
        private System.Windows.Forms.ColumnHeader description;
        private System.Windows.Forms.ColumnHeader discontinued;
        private System.Windows.Forms.Button btnClose;
    }
}