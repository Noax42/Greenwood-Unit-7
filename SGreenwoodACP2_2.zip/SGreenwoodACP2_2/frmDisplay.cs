﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace SGreenwoodACP2_2
{
    public partial class frmDisplay : Form
    {
        public frmDisplay()
        {
            InitializeComponent();
        }

        //Connection object
        SQLiteConnection connection;

        private void frmDisplay_Load(object sender, EventArgs e)
        {
            connection = CreateConnection();

            //Establish reader and command objects
            SQLiteDataReader dr;
            SQLiteCommand cmd;
            cmd = connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM beverages";

            //Use reader to get data from table
            dr = cmd.ExecuteReader();

            //Array and object to hold row values
            ListViewItem row;
            string[] rowValues = new string[7];

            //Start loading the list view
            while(dr.Read())
            {
                //Read the data into rowValues
                rowValues[0] = dr.GetInt32(0).ToString();       //ID
                rowValues[1] = dr.GetString(1);                 //Name
                rowValues[2] = dr.GetDouble(2).ToString();      //Price
                rowValues[3] = dr.GetInt32(3).ToString();       //Quantity
                rowValues[4] = dr.GetInt32(4).ToString();       //Year Produced
                rowValues[5] = dr.GetString(5);                 //Description
                rowValues[6] = dr.GetInt32(6).ToString();       //Discontinued

                //Add these values to row and place it in the list view
                row = new ListViewItem(rowValues);
                lvwDisplay.Items.Add(row);
            }
        }

        //Function to create database and set up connection
        static SQLiteConnection CreateConnection()
        {
            //Create return object and data source file
            SQLiteConnection con;
            con = new SQLiteConnection("Data Source=sodaCompany.db");

            //Open the connection
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return con;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //Close this form
            this.Close();
        }
    }
}
