﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;

namespace SGreenwoodACP2_2
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        //Connection object
        SQLiteConnection connection;

        private void frmMain_Load(object sender, EventArgs e)
        {
            //Connect to database file
            connection = CreateConnection();
        }

        //Function to create database and set up connection
        static SQLiteConnection CreateConnection()
        {
            //Create return object and data source file
            SQLiteConnection con;
            con = new SQLiteConnection("Data Source=sodaCompany.db");

            //Open the connection
            try
            {
                con.Open();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return con;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            //Create a command object
            SQLiteCommand cmd;
            cmd = connection.CreateCommand();

            //Drop the table before operation
            cmd.CommandText = "DROP TABLE IF EXISTS beverages";
            cmd.ExecuteNonQuery();

            //Create the beverages table
            cmd.CommandText = @"CREATE TABLE beverages(id INTEGER PRIMARY KEY, " +
                                                     @"name TEXT, " +
                                                     @"price REAL, " +
                                                     @"quantity INTEGER, " +
                                                     @"yearProduced INTEGER, " +
                                                     @"description TEXT, " +
                                                     @"discontinued INTEGER)";
            cmd.ExecuteNonQuery();

            //Notify table creation
            MessageBox.Show("Beverage Table created.");
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            //Create a command object
            SQLiteCommand cmd;
            cmd = connection.CreateCommand();

            //Insert 15 Fake Soda entries
            //1
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Stackola', 1.89, 927, 2015, 'The Hat Stacker take on the cola recipe.', 0)";
            cmd.ExecuteNonQuery();
            //2
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Prof. Pip', 1.94, 823, 2017, 'A savory blend of 24 flavors.', 0)";
            cmd.ExecuteNonQuery();
            //3
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Big Green', 1.83, 1032, 2018, 'Complimentary in color and flavor to Big Red.', 0)";
            cmd.ExecuteNonQuery();
            //4
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('W&A Root Beer', 2.01, 539, 2015, 'Famous root beer that is wanted and available.', 0)";
            cmd.ExecuteNonQuery();
            //5
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Savannah Fog', 1.84, 0, 2016, 'The lemon-lime soda overshadowed by everything.', 1)";
            cmd.ExecuteNonQuery();
            //6
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Pixie', 1.99, 763, 2017, 'Nothing says lemon-lime like mystic creatures.', 0)";
            cmd.ExecuteNonQuery();
            //7
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Summit Dew', 2.23, 145, 2019, 'Taking gaming sodas to the highest level.', 0)";
            cmd.ExecuteNonQuery();
            //8
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Moonkist Orange', 1.96, 503, 2016, 'The classic fruit flavored soda from Moonkist', 0)";
            cmd.ExecuteNonQuery();
            //9
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Moonkist Grape', 1.95, 546, 2016, 'Moonkist knows that everything grape is good.', 0)";
            cmd.ExecuteNonQuery();
            //10
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Bebsi', 1.83, 984, 2015, 'It is just like Stackola, but with a different name.', 0)";
            cmd.ExecuteNonQuery();
            //11
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Down7', 1.91, 792, 2018, 'A lemon-lime soda brimming with confidence.', 0)";
            cmd.ExecuteNonQuery();
            //12
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Stacker Gingerale', 1.95, 523, 2017, 'Soda blessed with everything ginger has to offer.', 0)";
            cmd.ExecuteNonQuery();
            //13
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Pug Root Beer', 1.89, 701, 2018, 'Root beer with the company pug as a mascot.', 0)";
            cmd.ExecuteNonQuery();
            //14
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Smash Strawberry', 2.19, 428, 2020, 'The classic strawberry taste with the bubbles we love.', 0)";
            cmd.ExecuteNonQuery();
            //15
            cmd.CommandText = "INSERT INTO beverages(name, price, quantity, yearProduced, description, discontinued) " +
                              "VALUES ('Smash Pineapple', 1.89, 0, 2020, 'The soda that tries to do what pizza cannot.', 1)";
            cmd.ExecuteNonQuery();

            //Notify data insertion
            MessageBox.Show("Data for beverages has been inserted.");
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            //Open display form as modeless window
            new frmDisplay().Show();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            //Generate the report
            PrintReport(GenerateReport());
        }

        //Function to write the report code
        private StringBuilder GenerateReport()
        {
            StringBuilder html = new StringBuilder();
            StringBuilder css = new StringBuilder();

            //Set up the css header
            css.Append("<style>");
            //css.Append($"font-family:{"Lucidia Console"}, monospace;");
            css.Append(" td {padding:5px;text-align:center;font-weight:bold;text-align:center;}");
            css.Append("h1{color: green;text-decoration:underline;font-family:Monaco, monospace;}");
            css.Append("</style>");

            //Place an image at the top of the html report
            html.Append($"<img src={"soda-can.jpg"}>");

            //Create html header using css code
            html.Append("<style>");
            html.Append($"<head>{css}<title>{"Beverage List"}</title></head>");
            html.Append("<body>");
            html.Append($"<h1>{"Beverage List"}</h1>");

            //Establish reader and command objects
            SQLiteDataReader dr;
            SQLiteCommand cmd;
            cmd = connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM beverages";

            //Use reader to get data from table
            dr = cmd.ExecuteReader();

            //Create table data
            html.Append("<table>");
            html.Append("<tr><td colspan=7><hr/></td></tr>");
            html.Append("<tr>");

            //Write the column titles
            html.Append($"<td>{"ID"}</td>");
            html.Append($"<td>{"Name"}</td>");
            html.Append($"<td>{"Price"}</td>");
            html.Append($"<td>{"Quantity"}</td>");
            html.Append($"<td>{"Year Produced"}</td>");
            html.Append($"<td>{"Description"}</td>");
            html.Append($"<td>{"Discontinued"}</td>");
            html.Append("</tr>");
            html.Append("<tr><td colspan=7><hr/></td></tr>");

            //Array to hold row values
            string[] rowValues = new string[7];

            //Read the data into the array and report
            while (dr.Read())
            {
                rowValues[0] = dr.GetInt32(0).ToString();       //ID
                rowValues[1] = dr.GetString(1);                 //Name
                rowValues[2] = dr.GetDouble(2).ToString();      //Price
                rowValues[3] = dr.GetInt32(3).ToString();       //Quantity
                rowValues[4] = dr.GetInt32(4).ToString();       //Year Produced
                rowValues[5] = dr.GetString(5);                 //Description
                rowValues[6] = dr.GetInt32(6).ToString();       //Discontinued

                html.Append($"<td>{dr.GetInt32(0)}</td>");
                html.Append($"<td>{dr.GetString(1)}</td>");
                html.Append($"<td>{"$" + dr.GetDouble(2)}</td>");
                html.Append($"<td>{dr.GetInt32(3)}</td>");
                html.Append($"<td>{dr.GetInt32(4)}</td>");
                html.Append($"<td>{dr.GetString(5)}</td>");
                html.Append($"<td>{dr.GetInt32(6)}</td>");
                html.Append("</tr>");
            }

            //Ending lines
            html.Append("<tr><td colspan=8><hr/></td></tr>");
            html.Append("</table>");
            html.Append("<br><br>Created by Scott Greenwood");
            html.Append("</body></html>");

            return html;
        }

        //Function to write the report file using html
        private void PrintReport(StringBuilder html)
        {
            //Get the current date and time
            DateTime today = DateTime.Now;

            //Write to hard drive using the name report.txt
            try
            {
                using (StreamWriter sw = new StreamWriter($"{today.ToString("yyyy-MM-dd HH-mm-ss")} - Report.html"))
                {
                    sw.WriteLine(html);
                }

                System.Diagnostics.Process.Start($"{today.ToString("yyyy-MM-dd HH-mm-ss")} - Report.html");
            }
            catch
            {
                MessageBox.Show("You don't have write permissions", "Error System Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnAbout_Click(object sender, EventArgs e)
        {
            //Open the about form as a modal window
            new frmAbout().ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Exit the application
            Application.Exit();
        }
    }
}
