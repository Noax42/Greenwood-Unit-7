#include "enemy.h"


Enemy::Enemy(SDL_Renderer* renderer)
{
	//Constructor for Enemy objects
	//Create surface object
	SDL_Surface* surface = IMG_Load("./Assets/Enemy.PNG");

	//Place the surface into texture
	texture = SDL_CreateTextureFromSurface(renderer, surface);

	//Free the surface
	SDL_FreeSurface(surface);

	//Init width and height values and query the texture to fill them in
	int w, h;
	SDL_QueryTexture(texture, NULL, NULL, &w, &h);

	//Set the rectangle width and height
	posRect.w = w;
	posRect.h = h;

	//Reset the enemy
	Reset();

	//Set to move left
	xDir = -1;
	yDir = 0;
}

void Enemy::Reset()
{
	//Function to reset the enemy speed and position
	//Set speed to a random number between 1-5, then multiply it by 100
	speed = rand() % (5) + 1;
	speed *= 100;

	//Spawn the enemy off the right side of the screen, with a random y value
	posRect.x = 1024 + posRect.w;
	posRect.y = rand() % (768 - posRect.h) + 1;

	//Set the position floats
	posX = posRect.x;
	posY = posRect.y;
}

void Enemy::Update(float deltaTime)
{
	//Function to update enemy information
	//Move the enemy
	posX += (speed * xDir) * deltaTime;

	//Update the rectangle
	posRect.x = (int)(posX + 0.5f);

	//Reset the enemy if they go off the left side of the screen
	if (posRect.x < (0 - posRect.w))
	{
		Reset();
	}
}

void Enemy::Draw(SDL_Renderer* renderer)
{
	//Prepare to draw the enemy
	SDL_RenderCopy(renderer, texture, NULL, &posRect);
}

Enemy::~Enemy()
{
	//Destroy the enemy
	//SDL_DestroyTexture(texture);
}