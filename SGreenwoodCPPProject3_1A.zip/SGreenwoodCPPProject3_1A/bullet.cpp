#include "bullet.h"

Bullet::Bullet(SDL_Renderer* renderer, float x, float y)
{
	//Constructor for Bullet objects
	//Set bullet to be inactive
	active = false;

	//Set speed
	speed = 800.0f;

	//Create SDL surface
	SDL_Surface* surface = IMG_Load("./Assets/Laser.PNG");

	//Place surface into the texture
	texture = SDL_CreateTextureFromSurface(renderer, surface);

	//Check if the texture failed to load
	if (texture == NULL)
	{
		printf("Unable to load image %s! SDL_image Error: %s\n", ".Assets/Laser.PNG", IMG_GetError());
	}

	//Free the surface
	SDL_FreeSurface(surface);

	//Init width and height values and query the texture to fill them in
	int w, h;
	SDL_QueryTexture(texture, NULL, NULL, &w, &h);

	//Set the rectangle width and height
	posRect.w = w;
	posRect.h = h;

	//Set Rectangle position
	posRect.x = x + posRect.w;
	posRect.y = y + (posRect.h / 2);

	//Set position float
	posX = x;
	posY = y;

	//Set movement
	xDir = 1;
	yDir = 0;
}

void Bullet::Reset()
{
	//Function to reset bullet position and activity
	//Turn off the bullet
	active = false;

	//Set bullet aside
	posRect.x = -1000;
	posRect.y = -1000;

	//Update float values
	posX = posRect.x;
	posY = posRect.y;
}

void Bullet::Update(float deltaTime)
{
	//Function to update information of an active bullet
	//Check if the bullet is active
	if (active)
	{
		//Move the bullet
		posX += (speed * xDir) * deltaTime;

		//Update the rectangle
		posRect.x = (int)(posX + 0.5f);

		//Reset the bullet if it goes off the right side of the screen
		if (posRect.x > (1024 + posRect.w))
		{
			Reset();
		}
	}
}

void Bullet::Draw(SDL_Renderer* renderer)
{
	//Prepare to draw the bullet
	SDL_RenderCopy(renderer, texture, NULL, &posRect);
}

Bullet::~Bullet()
{
	//Destroy the texture
	//SDL_DestroyTexture(texture);
}