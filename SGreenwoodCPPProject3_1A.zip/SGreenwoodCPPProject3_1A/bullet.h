#pragma once

//Includes for enemy
#include <SDL.h>
#include <SDL_image.h>

#include <iostream>
using namespace std;

class Bullet
{
public:
	//Variables
	bool active;			//Is the bullet active?
	SDL_Texture* texture;	//Texture to draw bullet with
	SDL_Rect posRect;		//Rectangle to keep track of x, y, w, and h
	float xDir, yDir;		//Determines which direction bullet moves
	float speed;			//Determines the speed at which bullet moves
	float posX, posY;		//Keeps track of position and handles float-to-int conversion

	//Function prototypes
	Bullet(SDL_Renderer* renderer, float x, float y);
	void Update(float deltaTime);
	void Draw(SDL_Renderer* renderer);
	void Reset();
	~Bullet();
};