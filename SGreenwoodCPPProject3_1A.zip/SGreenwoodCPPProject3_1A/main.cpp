//SDL Includes
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>

//Header includes
#include "enemy.h"
#include "bullet.h"

//Other includes
#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

//Global Variables
bool quit = false;							//Bool to manage game loop

float deltaTime = 0.0;						//Holds the change in time from frame to frame
int thisTime = 0;							//Holds the number of ticks of the current frame
int lastTime = 0;							//Holds the number of ticks of the previous frame

float playerSpeed = 500.0f;					//Determines how fast the player moves
float yDir;									//Determines the vertical direction of the player
float posX, posY;							//Holds the player's position in x and y
SDL_Rect playerPos;							//Rectangle to hold the player in the game world

vector<Enemy> enemyList;					//List to hold all enemies in the game world
vector<Bullet> bulletList;					//List to hold all enemies in the game world

Mix_Chunk* laser;							//Holds the laser sound effect
Mix_Chunk* explosion;						//Holds the explosion sound effect
Mix_Music* bgm;								//Holds the background music loop

int playerScore, oldScore;					//Ints to manage score values
int playerLives, oldLives;					//Ints to manage life values
TTF_Font* font;								//Holds the font being used for the UI
SDL_Color colorP1 = { 0, 255, 0, 255 };		//The color being used for the font
SDL_Surface* scoreSurface, * livesSurface;	//Surface objects to hold the score and life UI
SDL_Texture* scoreTexture, * livesTexture;	//Texture objects to represent score and life UI in the game world
SDL_Rect scorePos, livesPos;				//Rectangles for score and life UI
string tempScore, tempLives;				//Temporary values for operating with score and life values

//Functions
void CreateBullet()
{
	//Function to activate the first standby bullet
	//Cycle through all bullets
	for (int i = 0; i < bulletList.size(); i++)
	{
		//Look for an inactive bullet
		if (!bulletList[i].active)
		{
			//Play laser sound
			Mix_PlayChannel(-1, laser, 0);

			//Activate this bullet
			bulletList[i].active = true;

			//Set the bullet's x position
			bulletList[i].posRect.x = playerPos.x + playerPos.w;

			//Set the bullet's y position
			bulletList[i].posRect.y = (posY + (playerPos.h / 2));
			bulletList[i].posRect.y = (bulletList[i].posRect.y - (bulletList[i].posRect.h / 2));

			//Set the position floats
			bulletList[i].posX = playerPos.x;
			bulletList[i].posY = posY;

			//Stop loop here
			break;
		}
	}
}

void UpdateScore(SDL_Renderer* renderer)
{
	//Function for updating the Score UI
	//Create the text
	tempScore = "Player Score: " + std::to_string(playerScore);

	//Use RenderText to create a surface
	scoreSurface = TTF_RenderText_Solid(font, tempScore.c_str(), colorP1);

	//Place the surface in the score texture
	scoreTexture = SDL_CreateTextureFromSurface(renderer, scoreSurface);

	//Get the width and height of the texture and set the rectangle values
	SDL_QueryTexture(scoreTexture, NULL, NULL, &scorePos.w, &scorePos.h);

	//Free the surface
	SDL_FreeSurface(scoreSurface);

	//Record the old score
	oldScore = playerScore;
}

void UpdateLives(SDL_Renderer* renderer)
{
	//Function for updating the Lives UI
	//Create the text
	tempLives = "Player Lives: " + std::to_string(playerLives);

	//Use RenderText to create a surface
	livesSurface = TTF_RenderText_Solid(font, tempLives.c_str(), colorP1);

	//Place the surface in the score texture
	livesTexture = SDL_CreateTextureFromSurface(renderer, livesSurface);

	//Get the width and height of the texture and set the rectangle values
	SDL_QueryTexture(livesTexture, NULL, NULL, &livesPos.w, &livesPos.h);

	//Free the surface
	SDL_FreeSurface(livesSurface);

	//Record the old life value
	oldLives = playerLives;
}

int main(int argc, char* argv[])
{
	//Create window
	SDL_Window* window;

	//Create renderer
	SDL_Renderer* renderer = NULL;

	//Init SDL2
	SDL_Init(SDL_INIT_EVERYTHING);

	//Create the game window with the following settings
	window = SDL_CreateWindow(
		"Space Wars",					//Window title
		SDL_WINDOWPOS_UNDEFINED,		//X Position
		SDL_WINDOWPOS_UNDEFINED,		//Y Position
		1024,							//Width in pixels
		768,							//Height in pixels
		SDL_WINDOW_OPENGL				//Flags
	);

	//Check if the window opened successfully
	if (window == NULL)
	{
		printf("Could not create window: %s\n", SDL_GetError());
		return 1;
	}

	//Create renderer object
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	//BACKGROUND IMAGE CREATE*************************************

	//Create surface for background
	SDL_Surface* surface = IMG_Load("./Assets/background.PNG");

	//Create background texture
	SDL_Texture* bkgd;

	//Place the surface into the background texture
	bkgd = SDL_CreateTextureFromSurface(renderer, surface);

	//Free the surface
	SDL_FreeSurface(surface);

	//Create rectangle for the background object
	SDL_Rect bkgdPos;

	//Set the rectangle values
	bkgdPos.x = 0;
	bkgdPos.y = 0;
	bkgdPos.w = 1024;
	bkgdPos.h = 768;

	//BACKGROUND IMAGE END****************************************

	//PLAYER IMAGE CREATE*****************************************

	//Load the player image into the surface
	surface = IMG_Load("./Assets/Player.PNG");

	//Create the player texture
	SDL_Texture* player;

	//Place the surface into the player texture
	player = SDL_CreateTextureFromSurface(renderer, surface);

	//Free the surface
	SDL_FreeSurface(surface);

	//Set playerPos values
	playerPos.x = 68;
	playerPos.y = 384;
	playerPos.w = 126;
	playerPos.h = 57;

	//PLAYER IMAGE END********************************************

	//Create an SDL Event to handle input
	SDL_Event event;

	//Create bullets for the bullet list
	for (int i = 0; i < 10; i++)
	{
		Bullet tempBullet(renderer, i + 5, i + 5);
		bulletList.push_back(tempBullet);
	}

	//Clear Enemy List, then refill it with fresh enemies
	enemyList.clear();

	for (int i = 0; i < 8; i++)
	{
		Enemy tempEnemy(renderer);
		enemyList.push_back(tempEnemy);
	}

	//Init audio playback
	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

	//Load laser sound
	laser = Mix_LoadWAV("./Assets/laser.wav");

	//Load explosion sound
	explosion = Mix_LoadWAV("./Assets/explosion.wav");

	//Load and loop background music
	bgm = Mix_LoadMUS("./Assets/bkgd.wav");

	//If the music is not playing, play it and loop it
	if (!Mix_PlayingMusic())
	{
		Mix_PlayMusic(bgm, -1);
	}

	//Init the score and life values
	oldScore = 0;
	playerScore = 0;
	oldLives = 0;
	playerLives = 5;

	//Init Font
	TTF_Init();

	//Call the font
	font = TTF_OpenFont("./Assets/cyberdyne.ttf", 20);

	//Set up UI rectangles
	scorePos.x = 400;
	scorePos.y = 25;
	livesPos.x = 800;
	livesPos.y = 25;

	//Update Lives and Score
	UpdateScore(renderer);
	UpdateLives(renderer);

	//Set up game state enums
	enum GameState { GAME, WIN, LOSE };

	//Create gamestate variable and set it to game
	GameState gameState = GAME;

	//Create bools for moving from state to state
	bool game, win, lose;

	//Start game loop
	while (!quit)
	{
		//Check game state
		switch (gameState)
		{
		case GAME:
			//Set game state bool to true
			game = true;

			//Output for game
			std::cout << "The Game State is GAME" << endl << endl;

			//Load regular background
			surface = IMG_Load("./Assets/background.PNG");

			//Place surface into the texture
			bkgd = SDL_CreateTextureFromSurface(renderer, surface);

			//Free the surface
			SDL_FreeSurface(surface);

			//Start the game fresh
			//Refresh the enemy list
			enemyList.clear();

			for (int i = 0; i < 8; i++)
			{
				Enemy tempEnemy(renderer);
				enemyList.push_back(tempEnemy);
			}

			//Reset player score and lives
			playerScore = 0;
			playerLives = 5;

			//Loop for game
			while (game)
			{
				//Create deltaTime
				thisTime = SDL_GetTicks();
				deltaTime = (float)(thisTime - lastTime) / 1000;
				lastTime = thisTime;

				//Check for input
				if (SDL_PollEvent(&event))
				{
					//Close window by the window's x button
					if (event.type == SDL_QUIT)
					{
						quit = true;
						game = false;
						break;
					}

					switch (event.type)
					{
						//Look for a keypress
					case SDL_KEYUP:
						
						//Check for spacebar
						switch (event.key.keysym.sym)
						{
						case SDLK_SPACE:
							CreateBullet();
							break;
						default:
							break;
						}
					}
				}

				//Player Movement
				//Get the keyboard state
				const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL);

				//Move up and down when the right keys are pressed
				if (currentKeyStates[SDL_SCANCODE_UP] || currentKeyStates[SDL_SCANCODE_W])
				{
					yDir = -1;
				}
				else if (currentKeyStates[SDL_SCANCODE_DOWN] || currentKeyStates[SDL_SCANCODE_S])
				{
					yDir = 1;
				}
				else
				{
					yDir = 0;
				}

				//UPDATE ********************************************

				//Get new position to move player using direction and deltaTime
				posY += (playerSpeed * yDir) * deltaTime;

				//Move the player
				playerPos.y = (int)(posY + 0.5f);

				//Keep player on the screen
				//Moving up
				if (playerPos.y < 0)
				{
					playerPos.y = 0;
					posY = 0;
				}

				//Moving down
				if (playerPos.y > 768 - playerPos.h)
				{
					playerPos.y = 768 - playerPos.h;
					posY = 768 - playerPos.h;
				}

				//Update bullets
				for (int i = 0; i < 10; i++)
				{
					//Cycle through and update all active bullets
					if (bulletList[i].active)
					{
						bulletList[i].Update(deltaTime);
					}
				}

				//Update enemies
				for (int i = 0; i < 8; i++)
				{
					enemyList[i].Update(deltaTime);
				}

				//Collision check for bullets to enemies
				//For loop to check player's bullets
				for (int i = 0; i < bulletList.size(); i++)
				{
					//Check if this bullet is active
					if (bulletList[i].active)
					{
						//Nested for loop to check enemies
						for (int j = 0; j < enemyList.size(); j++)
						{
							//See if there is an interaction between the bullet and enemy
							if (SDL_HasIntersection(&bulletList[i].posRect, &enemyList[j].posRect))
							{
								//Play the explosion sound
								Mix_PlayChannel(-1, explosion, 0);

								//Reset the enemy
								enemyList[j].Reset();

								//Reset the bullet
								bulletList[i].Reset();

								//Give the player 50 points
								playerScore += 10;

								//Check to see if the player wins
								if (playerScore >= 500)
								{
									game = false;
									gameState = WIN;
								}
							}
						}
					}
				}

				//Collision check for player to enemies
				//Check for collision with the player and all enemies
				for (int i = 0; i < enemyList.size(); i++)
				{
					//See if there is a collision between the player and this enemy using SDL
					if (SDL_HasIntersection(&playerPos, &enemyList[i].posRect))
					{
						//Play the explosion sound
						Mix_PlayChannel(-1, explosion, 0);

						//Reset the enemy
						enemyList[i].Reset();

						//Remove 1 life
						playerLives -= 1;

						//Check to see if the player loses
						if (playerLives <= 0)
						{
							game = false;
							gameState = LOSE;
						}
					}
				}

				//Update score and lives if their values changed
				if (playerScore != oldScore)
				{
					UpdateScore(renderer);
				}

				if (playerLives != oldLives)
				{
					UpdateLives(renderer);
				}

				//UPDATE END ****************************************

				//DRAW **********************************************

				//Clear the old buffer
				SDL_RenderClear(renderer);

				//Prepare to draw the background
				SDL_RenderCopy(renderer, bkgd, NULL, &bkgdPos);

				//Draw active bullets
				for (int i = 0; i < 10; i++)
				{
					if (bulletList[i].active)
					{
						bulletList[i].Draw(renderer);
					}
				}

				//Prepare to draw player
				SDL_RenderCopy(renderer, player, NULL, &playerPos);

				//Draw enemies
				for (int i = 0; i < 8; i++)
				{
					enemyList[i].Draw(renderer);
				}

				//Draw score texture
				SDL_RenderCopy(renderer, scoreTexture, NULL, &scorePos);

				//Draw lives texture
				SDL_RenderCopy(renderer, livesTexture, NULL, &livesPos);

				//Draw all new info to the screen
				SDL_RenderPresent(renderer);

				//DRAW END ******************************************
			}
			break;

		case WIN:
			//Set win state bool to true
			win = true;

			//Output for win
			std::cout << "The Game State is WIN" << endl;
			std::cout << "Press the R Key to Replay the Game" << endl;
			std::cout << "Press the Q Key to Quit the Game" << endl;
			std::cout << endl;

			//BACKGROUND IMAGE ***************************************

			//Load the win background
			surface = IMG_Load("./Assets/win.png");

			//Place the surface into the texture
			bkgd = SDL_CreateTextureFromSurface(renderer, surface);

			//Free the surface
			SDL_FreeSurface(surface);

			//BACKGROUND IMAGE END ***********************************

			//Loop for win
			while (win)
			{
				//Create deltaTime
				thisTime = SDL_GetTicks();
				deltaTime = (float)(thisTime - lastTime) / 1000;
				lastTime = thisTime;

				//Check for input
				if (SDL_PollEvent(&event))
				{
					//Close window by the window's X button
					if (event.type == SDL_QUIT)
					{
						quit = true;
						win = false;
						break;
					}

					switch (event.type)
					{
						//Check for keypress
					case SDL_KEYUP:

						//Check for SDLKey values and change state accordingly
						switch (event.key.keysym.sym)
						{
						case SDLK_r:
							win = false;
							gameState = GAME;
							break;
						case SDLK_q:
							win = false;
							quit = true;
							break;
						default:
							break;
						}
					}
				}

				//DRAW *************************

				//Clear the old buffer
				SDL_RenderClear(renderer);

				//Prepare to draw background
				SDL_RenderCopy(renderer, bkgd, NULL, &bkgdPos);

				//Draw new info to the screen
				SDL_RenderPresent(renderer);

				//DRAW END *********************

			}
			break;

		case LOSE:
			//Set lose state bool to true
			lose = true;

			//Output for lose
			std::cout << "The Game State is LOSE" << endl;
			std::cout << "Press the R Key to Replay the Game" << endl;
			std::cout << "Press the Q Key to Quit the Game" << endl;
			std::cout << endl;

			//BACKGROUND IMAGE ***************************************

			//Load the win background
			surface = IMG_Load("./Assets/lose.png");

			//Place the surface into the texture
			bkgd = SDL_CreateTextureFromSurface(renderer, surface);

			//Free the surface
			SDL_FreeSurface(surface);

			//BACKGROUND IMAGE END ***********************************

			//Loop for lose
			while (lose)
			{
				//Create deltaTime
				thisTime = SDL_GetTicks();
				deltaTime = (float)(thisTime - lastTime) / 1000;
				lastTime = thisTime;

				//Check for input
				if (SDL_PollEvent(&event))
				{
					//Close window by the window's X button
					if (event.type == SDL_QUIT)
					{
						quit = true;
						lose = false;
						break;
					}

					switch (event.type)
					{
						//Check for keypress
					case SDL_KEYUP:

						//Check for SDLKey values and change state accordingly
						switch (event.key.keysym.sym)
						{
						case SDLK_r:
							lose = false;
							gameState = GAME;
							break;
						case SDLK_q:
							lose = false;
							quit = true;
							break;
						default:
							break;
						}
					}
				}

				//DRAW *************************

				//Clear the old buffer
				SDL_RenderClear(renderer);

				//Prepare to draw background
				SDL_RenderCopy(renderer, bkgd, NULL, &bkgdPos);

				//Draw new info to the screen
				SDL_RenderPresent(renderer);

				//DRAW END *********************
			}
			break;
		}
	}

	//Close and destroy the window
	SDL_DestroyWindow(window);

	//Clean up
	SDL_Quit();

	return 0;
}