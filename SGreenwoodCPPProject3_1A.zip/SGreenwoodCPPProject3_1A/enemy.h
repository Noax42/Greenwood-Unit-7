#pragma once

//Includes for enemy
#include <SDL.h>
#include <SDL_image.h>

#include <iostream>
using namespace std;

class Enemy
{
public:
	//Variables
	bool active;			//Is the enemy active?
	SDL_Texture* texture;	//Texture to draw enemy with
	SDL_Rect posRect;		//Rectangle to keep track of x, y, w, and h
	float xDir, yDir;		//Determines which direction enemy moves
	float speed;			//Determines the speed at which enemy moves
	float posX, posY;		//Keeps track of position and handles float-to-int conversion

	//Function Prototypes
	Enemy(SDL_Renderer* renderer);
	void Update(float deltaTime);
	void Draw(SDL_Renderer* renderer);
	void Reset();
	~Enemy();
};